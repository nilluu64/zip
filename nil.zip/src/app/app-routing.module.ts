import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { InitialComponent } from './initial/initial.component';
import { ReviewComponent } from './initial/review/review.component';

const routes: Routes = [
  {path: '',
  pathMatch:'full',
  redirectTo: 'initial'
 },
 {
  path:'initial', component: InitialComponent,
 },
 {
  path:'search', component: ReviewComponent
 }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
