import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Router } from '@angular/router';
import { NavItem } from './navItem';
import { HostListener } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  
})
export class AppComponent {
  @HostListener('window:beforeunload', ['$event'])
  beforeunloadHandler(event:any) {
    return false;
    //I have used return false but you can your other functions or any query or condition
  }
  title = 'DHS NavBar';
  hide:boolean = false;
  show() {
    this.hide = !this.hide;
  }
  country = ['A', 'B', 'C'];
  @ViewChild(MatSidenav) sideNav!: MatSidenav;
  constructor(public router: Router) {}

  closeAllSideNav(){
    this.sideNav.close();
  }
  public case : boolean = false;
  toggleButton(){
    this.case = !this.case;
  }

  menu: NavItem [] = [
    // {
    //   displayName: 'Dashboard',
    //   iconName: 'desktop_windows',
    //   route: '/initial',
    // },        
    // {
    //   displayName: 'Program',
    //   iconName: 'ballot',
    //   route: '',
    // },
    // {
    //   displayName: 'Data Entry Function',
    //   iconName: '',
    //   route: ''
    // },
    {
      displayName: 'Eligibility Application',
      iconName: '',
      route: '',          
      children: [
        {
          displayName: 'Initial',
          iconName: 'how_to_reg',
          route: '/initial'
        },
        { 
          displayName: 'Update/View',
          iconName: 'waves',
          route: '/'
        },
        { 
          displayName: 'Redeter',
          iconName: 'waves',
          route: '/'
        },
        { 
          displayName: 'Logout',
          iconName: 'waves',
          route: '/'
        }
      ]
    },
    // {
    //   displayName: 'Search',
    //   iconName: 'search',
    //   route: '/search'
    // }
    // {
    //   displayName: 'P/A/P Application',
    //   iconName: '',
    // },
    // {
    //   displayName: 'Provider',
    //   iconName: '',
    // },
    // { 
    //   displayName: 'Agency',
    //   iconName: 'ballot',
    //   route: '/'
    // },
    // { 
    //   displayName: 'Security',
    //   iconName: 'ballot',
    //   route: '/'
    // },
    // { 
    //   displayName: 'System',
    //   iconName: 'ballot',
    //   route: '/'
    // },
    // { 
    //   displayName: 'Prefrence',
    //   iconName: 'ballot',
    //   route: '/'
    // },
    // { 
    //   displayName: 'Logout',
    //   iconName: 'ballot',
    //   route: '/'
    // },
  ];


}