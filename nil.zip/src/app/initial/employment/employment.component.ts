import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { EmploymentService } from './employment.service';

@Component({
  selector: 'app-employment',
  templateUrl: './employment.component.html',
  styleUrls: ['./employment.component.scss'],
})
export class EmploymentComponent implements OnInit {
  @Input() key: any;
  job = ['Part Time', 'Full Time'];
  frequency = ['Daily', 'Weekly', 'Monthly'];
  states = ['state 1', 'state 2'];
  isButtonVisible = true;
  @Input() masterKey: any;
  masterKeys: any;
  appMedicalIncapaciated: string = 'Medical Incapaciated';
  co_appMedicalIncapaciated: string = 'Medical Incapaciated';
  primarySchoolDoc: string = 'Primary School Document';
  SecondarySchoolDoc: string = 'Secondary School Document';
  primaryTrainingDoc: string = 'Primary Training Document';
  SecondaryTrainingDoc: string = 'Secondary Training Document';
  public parentIncapaCase: boolean = false;
  appMedicalIncapaciatedKey: any;
  errData: any;
  file: any;
  co_appMedicalIncapaciatedKey: any;
  primarySchoolDocKey: any;
  SecondarySchoolDocKey: any;
  primaryTrainingDocKey: any;
  SecondaryTrainingDocKey: any;

  primaryCoSchoolDoc: string = 'Co-Applicant`s Primary School Document';
  SecondaryCoSchoolDoc: string = 'Co-Applicant`s Secondary School Document';
  primaryCoTrainingDoc: string = 'Co-Applicant`s Primary Training Document';
  SecondaryCoTrainingDoc: string = 'Co-Applicant`s Secondary Training Document';

  primaryCoSchoolDocKey: any;
  SecondaryCoSchoolDocKey: any;
  primaryCoTrainingDocKey: any;
  SecondaryCoTrainingDocKey: any;

  parentIncapaciated() {
    this.parentIncapaCase = !this.parentIncapaCase;
  }
  public coParentIncapaCase: boolean = false;
  coParentIncapaciated() {
    this.coParentIncapaCase = !this.coParentIncapaCase;
  }
  public case1: boolean = false;
  toggleButton() {
    this.case1 = !this.case1;
  }

  public case2: boolean = false;
  toggleButton2() {
    this.case2 = !this.case2;
  }
  public case3: boolean = false;
  toggleButton3() {
    this.case3 = !this.case3;
  }
  public case4: boolean = false;
  toggleButton4() {
    this.case4 = !this.case4;
  }
  public case5: boolean = false;
  toggleButton5() {
    this.case5 = !this.case5;
  }
  public case6: boolean = false;
  toggleButton6() {
    this.case6 = !this.case6;
  }

  public coapp_case1: boolean = false;
  toggleButtonCoApp() {
    this.coapp_case1 = !this.coapp_case1;
  }

  public coapp_case2: boolean = false;
  toggleButtonCoApp2() {
    this.coapp_case2 = !this.coapp_case2;
  }
  public coapp_case3: boolean = false;
  toggleButtonCoApp3() {
    this.coapp_case3 = !this.coapp_case3;
  }
  public coapp_case4: boolean = false;
  toggleButtonCoApp4() {
    this.coapp_case4 = !this.coapp_case4;
  }
  public coapp_case5: boolean = false;
  toggleButtonCoApp5() {
    this.coapp_case5 = !this.coapp_case5;
  }
  public coapp_case6: boolean = false;
  toggleButtonCoApp6() {
    this.coapp_case6 = !this.coapp_case6;
  }
  state = ['1', '2', '3', '4'];
  state2 = ['1', '2', '3', '4'];
  visible: boolean = false;
  ReadMore: boolean = true;
  employmentForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private empService: EmploymentService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    //  this.getEmploymentData();
    this.employmentForm = this.formBuilder.group({
      appSelfEmployed: [],
      appMedicalEncapacited: [],
      appMedicalEncapacitedFile: [],

      coAppSelfEmployed: [],
      coAppMedicalEncapacited: [],
      coAppMedicalEncapacitedFile: [],

      primaryAppEmpPartTime: [],
      primaryAppEmpFulltTime: [],
      primaryAppEmpDate: [],
      primaryAppEmpName: [],
      primaryAppEmpPhoneNo: [],
      primaryAppEmpAddline1: [],
      primaryAppEmpAddline2: [],
      primaryAppEmpCity: [],
      primaryAppEmpState: [],
      primaryAppEmpZip: [],

      primaryAppSchoolHour: [],
      primaryAppSchoolDate: [],
      primaryAppSchoolName: [],
      primaryAppSchoolPhoneNo: [],
      primaryAppSchoolAddLine1: [],
      primaryAppSchoolAddLine2: [],
      primaryAppSchoolCity: [],
      primaryAppSchoolState: [],
      primaryAppSchoolZip: [],
      primaryAppSchoolfile: [],

      primaryAppTrainingHour: [],
      primaryAppTrainingDate: [],
      primaryAppTrainingSite: [],
      primaryAppTrainingPhoneNo: [],
      primaryAppTrainingAdd1: [],
      primaryAppTrainingAdd2: [],
      primaryAppTrainingCity: [],
      primaryAppTrainingState: [],
      primaryAppTrainingZip: [],
      primaryAppTrainingFile: [],

      coAppEmpPartTime: [],
      coAppEmpFulltTime: [],
      coAppEmpDate: [],
      coAppEmpName: [],
      coAppEmpPhoneNo: [],
      coAppEmpAddline1: [],
      coAppEmpAddline2: [],
      coAppEmpCity: [],
      coAppEmpState: [],
      coAppEmpZip: [],

      coAppSchoolHour: [],
      coAppSchoolDate: [],
      coAppSchoolName: [],
      coAppSchoolPhoneNo: [],
      coAppSchoolAddLine1: [],
      coAppSchoolAddLine2: [],
      coAppSchoolCity: [],
      coAppSchoolState: [],
      coAppSchoolZip: [],
      coAppSchoolfile: [],

      coAppTrainingHour: [],
      coAppTrainingDate: [],
      coAppTrainingSite: [],
      coAppTrainingPhoneNo: [],
      coAppTrainingAdd1: [],
      coAppTrainingAdd2: [],
      coAppTrainingCity: [],
      coTrainingState: [],
      coTrainingZip: [],
      coAppTrainingFile: [],

      state: [],
      state2: [],
    });
  }

  numberOnly(event: { which: any; keyCode: any }): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
  onSubmit() {
    if (this.employmentForm.invalid) {
      alert('Fill Form First');
      return;
    }
    console.log(this.employmentForm.value);
    this.employmentForm.reset();
  }
  onclick() {
    this.ReadMore = !this.ReadMore; //not equal to condition
    this.visible = !this.visible;
  }
  // getFile(event: any) {
  //   this.file = event.target.files[0];
  //   console.log('file', this.file);
  // }

  submitAppMedicalIncap(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appMedicalIncapaciated) {
      var filedata = {
        description: this.appMedicalIncapaciated,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.appMedicalIncapaciatedKey = newStr;
          },
        });
    }
  }
  submitCoAppMedicalIncap(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.co_appMedicalIncapaciated) {
      var filedata = {
        description: this.co_appMedicalIncapaciated,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.co_appMedicalIncapaciatedKey = newStr;
          },
        });
    }
  }

  submitPrimarySchool(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.primarySchoolDoc) {
      var filedata = {
        description: this.primarySchoolDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.primarySchoolDocKey = newStr;
          },
        });
    }
  }
  submitSecondarySchool(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.SecondarySchoolDoc) {
      var filedata = {
        description: this.SecondarySchoolDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.SecondarySchoolDocKey = newStr;
          },
        });
    }
  }

  submitPrimaryTraining(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.primaryTrainingDoc) {
      var filedata = {
        description: this.primaryTrainingDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.primaryTrainingDocKey = newStr;
          },
        });
    }
  }

  submitSecondaryTraining(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.SecondaryTrainingDoc) {
      var filedata = {
        description: this.SecondaryTrainingDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.SecondaryTrainingDocKey = newStr;
          },
        });
    }
  }

  submitCo_PrimarySchool(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.primaryCoSchoolDoc) {
      var filedata = {
        description: this.primaryCoSchoolDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.primaryCoSchoolDocKey = newStr;
          },
        });
    }
  }
  submitCo_SecondarySchool(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.SecondaryCoSchoolDoc) {
      var filedata = {
        description: this.SecondaryCoSchoolDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.SecondaryCoSchoolDocKey = newStr;
          },
        });
    }
  }

  submitCo_PrimaryTraining(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.primaryCoTrainingDoc) {
      var filedata = {
        description: this.primaryCoTrainingDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.primaryCoTrainingDocKey = newStr;
          },
        });
    }
  }

  submitCo_SecondaryTraining(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.SecondaryCoTrainingDoc) {
      var filedata = {
        description: this.SecondaryCoTrainingDoc,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.SecondaryCoTrainingDocKey = newStr;
          },
        });
    }
  }

  post() {
    let sendObj = {
      id: this.key,
      self_employed: true,
      co_self_employed: true,
      medical_incapaciated: this.appMedicalIncapaciatedKey,
      co_medical_incapaciated: this.co_appMedicalIncapaciatedKey,
      applicanttrainingdetails: [
        {
          hours_per_week: this.employmentForm.value.primaryAppTrainingHour,
          startdate: this.employmentForm.value.primaryAppTrainingDate,
          training_site: this.employmentForm.value.primaryAppTrainingSite,
          phone_number: this.employmentForm.value.primaryAppTrainingPhoneNo,
          address_line1: this.employmentForm.value.primaryAppTrainingAdd1,
          address_line2: this.employmentForm.value.primaryAppTrainingAdd2,
          city: this.employmentForm.value.primaryAppTrainingCity,
          state: this.employmentForm.value.primaryAppTrainingState,
          zip: this.employmentForm.value.primaryAppTrainingZip,
          upload_training_doc_applicant: this.primaryTrainingDocKey,
        },
        {
          hours_per_week: this.employmentForm.value.primaryAppTrainingHour,
          startdate: this.employmentForm.value.primaryAppTrainingDate,
          training_site: this.employmentForm.value.primaryAppTrainingSite,
          phone_number: this.employmentForm.value.primaryAppTrainingPhoneNo,
          address_line1: this.employmentForm.value.primaryAppTrainingAdd1,
          address_line2: this.employmentForm.value.primaryAppTrainingAdd2,
          city: this.employmentForm.value.primaryAppTrainingCity,
          state: this.employmentForm.value.primaryAppTrainingState,
          zip: this.employmentForm.value.primaryAppTrainingZip,
          upload_training_doc_applicant: this.SecondaryTrainingDocKey,
        },
      ],
      applicantschooldetail: [
        {
          classroom_class_hours: this.employmentForm.value.primaryAppSchoolHour,
          startdate: this.employmentForm.value.primaryAppSchoolDate,
          school_name: this.employmentForm.value.primaryAppSchoolName,
          phone_number: this.employmentForm.value.primaryAppSchoolPhoneNo,
          address_line1: this.employmentForm.value.primaryAppSchoolAddLine1,
          address_line2: this.employmentForm.value.primaryAppSchoolAddLine2,
          city: this.employmentForm.value.primaryAppSchoolCity,
          state: this.employmentForm.value.primaryAppSchoolState,
          zip: this.employmentForm.value.rimaryAppSchoolZip,
          upload_school_doc_applicant: this.primarySchoolDocKey,
        },
        {
          classroom_class_hours: this.employmentForm.value.primaryAppSchoolHour,
          startdate: this.employmentForm.value.primaryAppSchoolDate,
          school_name: this.employmentForm.value.primaryAppSchoolName,
          phone_number: this.employmentForm.value.primaryAppSchoolPhoneNo,
          address_line1: this.employmentForm.value.primaryAppSchoolAddLine1,
          address_line2: this.employmentForm.value.primaryAppSchoolAddLine2,
          city: this.employmentForm.value.primaryAppSchoolCity,
          state: this.employmentForm.value.primaryAppSchoolState,
          zip: this.employmentForm.value.rimaryAppSchoolZip,
          upload_school_doc_applicant: this.SecondarySchoolDocKey,
        },
      ],

      applicantemployementdetails: [
        {
          full_time: this.employmentForm.value.primaryAppEmpFulltTime,
          part_time: this.employmentForm.value.primaryAppEmpPartTime,
          startdate: this.employmentForm.value.primaryAppEmpDate,
          employer_name: this.employmentForm.value.primaryAppEmpName,
          phone_number: this.employmentForm.value.primaryAppEmpPhoneNo,
          address_line1: this.employmentForm.value.primaryAppEmpAddline1,
          address_line2: this.employmentForm.value.primaryAppEmpAddline2,
          city: this.employmentForm.value.primaryAppEmpCity,
          state: this.employmentForm.value.primaryAppEmpState,
          zip: this.employmentForm.value.primaryAppEmpZip,
        },
      ],
      coapplicanttrainingdetails: [
        {
          hours_per_week: this.employmentForm.value.coAppTrainingHour,
          startdate: this.employmentForm.value.coAppTrainingDate,
          training_site: this.employmentForm.value.coAppTrainingSite,
          phone_number: this.employmentForm.value.coAppTrainingPhoneNo,
          address_line1: this.employmentForm.value.coAppTrainingAdd1,
          address_line2: this.employmentForm.value.coAppTrainingAdd2,
          city: this.employmentForm.value.coAppTrainingCity,
          state: this.employmentForm.value.coTrainingState,
          zip: this.employmentForm.value.coTrainingZip,
          upload_training_doc_applicant: this.primaryCoTrainingDocKey,
        },
        {
          hours_per_week: this.employmentForm.value.coAppTrainingHour,
          startdate: this.employmentForm.value.coAppTrainingDate,
          training_site: this.employmentForm.value.coAppTrainingSite,
          phone_number: this.employmentForm.value.coAppTrainingPhoneNo,
          address_line1: this.employmentForm.value.coAppTrainingAdd1,
          address_line2: this.employmentForm.value.coAppTrainingAdd2,
          city: this.employmentForm.value.coAppTrainingCity,
          state: this.employmentForm.value.coTrainingState,
          zip: this.employmentForm.value.coTrainingZip,
          upload_training_doc_applicant: this.SecondaryCoTrainingDocKey,
        },
      ],
      coapplicantschooldetails: [
        {
          classroom_class_hours: this.employmentForm.value.coAppSchoolHour,
          startdate: this.employmentForm.value.coAppSchoolDate,
          school_name: this.employmentForm.value.coAppSchoolName,
          phone_number: this.employmentForm.value.coAppSchoolPhoneNo,
          address_line1: this.employmentForm.value.coAppSchoolAddLine1,
          address_line2: this.employmentForm.value.coAppSchoolAddLine2,
          city: this.employmentForm.value.coAppSchoolCity,
          state: this.employmentForm.value.coAppSchoolState,
          zip: this.employmentForm.value.coAppSchoolZip,
          upload_school_doc_coapplicant: this.primaryCoSchoolDocKey,
        },
        {
          classroom_class_hours: this.employmentForm.value.coAppSchoolHour,
          startdate: this.employmentForm.value.coAppSchoolDate,
          school_name: this.employmentForm.value.coAppSchoolName,
          phone_number: this.employmentForm.value.coAppSchoolPhoneNo,
          address_line1: this.employmentForm.value.coAppSchoolAddLine1,
          address_line2: this.employmentForm.value.coAppSchoolAddLine2,
          city: this.employmentForm.value.coAppSchoolCity,
          state: this.employmentForm.value.coAppSchoolState,
          zip: this.employmentForm.value.coAppSchoolZip,
          upload_school_doc_coapplicant: this.SecondaryCoSchoolDocKey,
        },
      ],
      coapplicantemployementdetails: [
        {
          full_time: this.employmentForm.value.coAppEmpFulltTime,
          part_time: this.employmentForm.value.coAppEmpPartTime,
          startdate: this.employmentForm.value.coAppEmpDate,
          employer_name: this.employmentForm.value.coAppEmpName,
          phone_number: this.employmentForm.value.coAppEmpPhoneNo,
          address_line1: this.employmentForm.value.coAppEmpAddline1,
          address_line2: this.employmentForm.value.coAppEmpAddline2,
          city: this.employmentForm.value.coAppEmpCity,
          state: this.employmentForm.value.coAppEmpState,
          zip: this.employmentForm.value.coAppEmpZip,
        },
      ],
    };

    console.log(sendObj);
    
    this.empService.postEmployment(sendObj).subscribe({
      next: (res) => {
        alert('Saved Succesfully');
      },
      error: () => {
        alert('Fill Demographic Form First...');
      },
    });
  }

  patch(masterKey: any) {
    let response: any;
    this.empService.getEmployment(masterKey).subscribe({
      next: (res: any) => {
        console.log(res);
        response = res;
        console.log('res variablr', response);

        this.employmentForm.patchValue({
          appSelfEmployed: response.self_employed,
          appMedicalEncapacited: response.medical_incapaciated,

          primaryAppEmpPartTime:
            response.applicantemployementdetails[0].part_time,
          primaryAppEmpFulltTime:
            response.applicantemployementdetails[0].full_time,
          primaryAppEmpDate: response.applicantemployementdetails[0].startdate,
          primaryAppEmpName:
            response.applicantemployementdetails[0].employer_name,
          primaryAppEmpPhoneNo:
            response.applicantemployementdetails[0].phone_number,
          primaryAppEmpAddline1:
            response.applicantemployementdetails[0].address_line1,
          primaryAppEmpAddline2:
            response.applicantemployementdetails[0].address_line2,
          primaryAppEmpCity: response.applicantemployementdetails[0].city,
          primaryAppEmpState: response.applicantemployementdetails[0].state,
          primaryAppEmpZip: response.applicantemployementdetails[0].zip,

          primaryAppSchoolHour:
            response.applicantschooldetails[0].classroom_class_hours,
          primaryAppSchoolDate: response.applicantschooldetails[0].startdate,
          primaryAppSchoolName: response.applicantschooldetails[0].school_name,
          primaryAppSchoolPhoneNo:
            response.applicantschooldetails[0].phone_number,
          primaryAppSchoolAddLine1:
            response.applicantschooldetails[0].address_line1,
          primaryAppSchoolAddLine2:
            response.applicantschooldetails[0].address_line2,
          primaryAppSchoolCity: response.applicantschooldetails[0].city,
          primaryAppSchoolState: response.applicantschooldetails[0].state,
          primaryAppSchoolZip: response.applicantschooldetails[0].zip,
          primaryAppSchoolfile:
            response.applicantschooldetails[0].upload_school_doc_applicant,

          primaryAppTrainingHour:
            response.applicanttrainingdetails[0].hours_per_week,
          primaryAppTrainingDate:
            response.applicanttrainingdetails[0].startdate,
          primaryAppTrainingSite:
            response.applicanttrainingdetails[0].training_site,
          primaryAppTrainingPhoneNo:
            response.applicanttrainingdetails[0].phone_number,
          primaryAppTrainingAdd1:
            response.applicanttrainingdetails[0].address_line1,
          primaryAppTrainingAdd2:
            response.applicanttrainingdetails[0].address_line2,
          primaryAppTrainingCity: response.applicanttrainingdetails[0].city,
          primaryAppTrainingState: response.applicanttrainingdetails[0].state,
          primaryAppTrainingZip: response.applicanttrainingdetails[0].zip,
          primaryAppTrainingFile:
            response.applicanttrainingdetails[0].upload_training_doc_applicant,

          coAppSelfEmployed: response.co_self_employed,
          coAppMedicalEncapacited: response.co_medical_incapaciated,

          coAppEmpPartTime: response.coapplicantemployementdetails[0].part_time,
          coAppEmpFulltTime:
            response.coapplicantemployementdetails[0].full_time,
          coAppEmpDate: response.coapplicantemployementdetails[0].startdate,
          coAppEmpName: response.coapplicantemployementdetails[0].employer_name,
          coAppEmpPhoneNo:
            response.coapplicantemployementdetails[0].phone_number,
          coAppEmpAddline1:
            response.coapplicantemployementdetails[0].address_line1,
          coAppEmpAddline2:
            response.coapplicantemployementdetails[0].address_line2,
          coAppEmpCity: response.coapplicantemployementdetails[0].city,
          coAppEmpState: response.coapplicantemployementdetails[0].state,
          coAppEmpZip: response.coapplicantemployementdetails[0].zip,

          coAppSchoolHour:
            response.coapplicantschooldetails[0].classroom_class_hours,
          coAppSchoolDate: response.coapplicantschooldetails[0].startdate,
          coAppSchoolName: response.coapplicantschooldetails[0].school_name,
          coAppSchoolPhoneNo: response.coapplicantschooldetails[0].phone_number,
          coAppSchoolAddLine1:
            response.coapplicantschooldetails[0].address_line1,
          coAppSchoolAddLine2:
            response.coapplicantschooldetails[0].address_line2,
          coAppSchoolCity: response.coapplicantschooldetails[0].city,
          coAppSchoolState: response.coapplicantschooldetails[0].state,
          coAppSchoolZip: response.coapplicantschooldetails[0].zip,
          coAppSchoolfile:
            response.coapplicantschooldetails[0].upload_school_doc_co_applicant,

          coAppTrainingHour:
            response.coapplicanttrainingdetails[0].hours_per_week,
          coAppTrainingDate: response.coapplicanttrainingdetails[0].startdate,
          coAppTrainingSite:
            response.coapplicanttrainingdetails[0].training_site,
          coAppTrainingPhoneNo:
            response.coapplicanttrainingdetails[0].phone_number,
          coAppTrainingAdd1:
            response.coapplicanttrainingdetails[0].address_line1,
          coAppTrainingAdd2:
            response.coapplicanttrainingdetails[0].address_line2,
          coAppTrainingCity: response.coapplicanttrainingdetails[0].city,
          coTrainingState: response.coapplicanttrainingdetails[0].state,
          coTrainingZip: response.coapplicanttrainingdetails[0].zip,
          coAppTrainingFile:
            response.coapplicanttrainingdetails[0]
              .upload_training_doc_coapplicant,
        });
      },
      error: (err: any) => {
        alert('Error');
      },
    });
  }
  getEmploymentData() {
    this.empService.getEmployment().subscribe({
      next: (res) => {
        console.log(res);
      },
      error: (err) => {
        alert(err);
      },
    });
  }
}
