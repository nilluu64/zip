import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmploymentService {

  constructor(private http: HttpClient) { }

  postEmployment(data:any){
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
    
    return this.http.post<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/employee/add',data,httpOptions)
  }

  getEmployment(masterKey?: any){
    return this.http.get<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/employee/get/'+masterKey);
  }
}
