import { TestBed } from '@angular/core/testing';

import { AddchildService } from './addchild.service';

describe('AddchildService', () => {
  let service: AddchildService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AddchildService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
