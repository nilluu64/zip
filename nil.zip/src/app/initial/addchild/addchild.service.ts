import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AddchildService {

  constructor(private http: HttpClient) { }

  postChild(data:any){
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
    return this.http.post<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/addchild/add',data,httpOptions)
  }

  getChild(masterKey?: any){
    console.log('from service',masterKey);
    return this.http.get<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/addchild/get/'+masterKey);
  }
}
