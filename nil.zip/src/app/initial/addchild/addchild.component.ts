import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AddchildService } from './addchild.service';

@Component({
  selector: 'app-addchild',
  templateUrl: './addchild.component.html',
  styleUrls: ['./addchild.component.scss'],
})
export class AddchildComponent implements OnInit {
  addChildForm: FormGroup;
  @Input() key: any;
  @Input() masterKey: any;
  masterKeys: any;
  racee = [
    'White/Caucasian',
    'Native American/Alaskan Native',
    'Asian',
    'Black/African American',
    'Native Hawaiian/Pacific islander',
    'Other',
  ];
  relationChild = [
    'Childs Birth Certificate',
    'Court Decree ',
    'Custody Agreement or other court documents for guardianship',
  ];
  identityChild = [
    'Birth Certificate',
    'Certificate of Citizenship',
    'Passport or Passport Card',
    'Social Security Card',
    'Permanent Resident Card',
    'Refugee Travel Document ',
    'Electronic version of U.S. Customs and Border Protection Form I-94 ',
  ];
  public switchCase: boolean = false;
  public case2: boolean = false;

  file: any;
  errData: any;
  documentedDisability: string = 'Child have documented disability';
  documentedDisabilityKey: any;
  permanentResident: string = 'US Citizen';
  permanentResidentKey: any;

  proof_of_child: string = '';
  proof_of_childKey: any;

  relationship_to_child: string = '';
  relationship_to_childKey: any;

  getFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
  }
  toggleFile() {
    this.switchCase = !this.switchCase;
  }
  toggleButton() {
    this.case2 = !this.case2;
  }
  row = [
    {
      id: '1',
      firstname: 'Alex',
      lastname: 'Desuza',
      gender: 'Male',
      age: '11',
      disability: 'No',
    },
    {
      id: '2',
      firstname: 'Peter',
      lastname: 'Sehgal',
      gender: 'Male',
      age: '8',
      disability: 'No',
    },
    {
      id: '3',
      firstname: 'Corbin',
      lastname: 'Miles',
      gender: 'Male',
      age: '5',
      disability: 'No',
    },
    {
      id: '4',
      firstname: 'Robin',
      lastname: 'Miles',
      gender: 'female',
      age: '12',
      disability: 'Yes',
    },
  ];

  ethnicityy = ['Hispanic/Latino', 'Non Hispanic/Latino'];
  genderr = ['Male', 'Female', 'Other'];
  agency = ['a', 'b', 'c', 'd'];

  constructor(
    private formBuilder: FormBuilder,
    private childservice: AddchildService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.addChildForm = this.formBuilder.group({
      lastname: ['', Validators.required],
      firstname: ['', Validators.required],
      mi: ['', Validators.required],
      ssn: ['', Validators.required],
      dob: ['', Validators.required],
      race: ['', Validators.required],
      ethnicity: ['', Validators.required],
      year: [],
      month: [],
      gender: ['', Validators.required],
      start_sunday: [],
      start_monday: [],
      start_tuesday: [],
      start_wednesday: [],
      start_thursday: [],
      start_friday: [],
      start_saturday: [],
      end_sunday: [],
      end_monday: [],
      end_tuesday: [],
      end_wednesday: [],
      end_thursday: [],
      end_friday: [],
      end_saturday: [],
      provider: [],
      proof_of_child: [],
      relationship_to_child: [],
      number_of_days: [],
      total_no_of_hours: [],
      cbc: [],
      sbn: [],
      spcify: [],
      ft_pt: [],
      program: [],
      status: [],
      school: [],
      term_dates: [],
      denial_date: [],
      dyf_case_number: [],
      njs_person_id: [],
      dyf_case_manager: [],
      ccap: [],
    });
    //  this.getAllChildren();
  }

  submitDocumentedDisability(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.documentedDisability) {
      var filedata = {
        description: this.documentedDisability,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.documentedDisabilityKey = newStr;
          },
        });
    }
  }
  submitUsResident(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.permanentResident) {
      var filedata = {
        description: this.permanentResident,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.permanentResidentKey = newStr;
          },
        });
    }
  }

  submitProofOfChild(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.proof_of_child) {
      var filedata = {
        description: this.proof_of_child,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.proof_of_childKey = newStr;
          },
        });
    }
  }

  submitProofOfRelationship(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.relationship_to_child) {
      var filedata = {
        description: this.relationship_to_child,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );
      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.relationship_to_childKey = newStr;
          },
        });
    }
  }

  get lastname() {
    return this.addChildForm.get('lastname')!;
  }
  get firstname() {
    return this.addChildForm.get('firstname')!;
  }
  get mi() {
    return this.addChildForm.get('mi')!;
  }
  get ssn() {
    return this.addChildForm.get('ssn')!;
  }
  get dob() {
    return this.addChildForm.get('dob')!;
  }
  get race() {
    return this.addChildForm.get('race')!;
  }
  get ethnicity() {
    return this.addChildForm.get('ethnicity')!;
  }
  get gender() {
    return this.addChildForm.get('gender')!;
  }

  // addTable() {
  //   const obj = {
  //     id: '',
  //     name: '',
  //     status: '',
  //   };
  //   this.row.push(obj);
  // }

  deleteRow(x: any) {
    this.row.splice(x, 1);
  }

  minutesToString(value: number): string {
    const hours = Math.floor(value / 60);
    return (
      (hours > 0 && hours < 99 ? ('00' + hours).slice(-2) : '' + hours) +
      ':' +
      ('00' + (hours % 60)).slice(-2)
    );
  }

  addChildFormData() {
    let sendObj = {
      id: this.key,
      lastname: this.addChildForm.value.lastname,
      firstname: this.addChildForm.value.firstname,
      mi: this.addChildForm.value.mi,
      ssn: this.addChildForm.value.ssn,
      race: this.addChildForm.value.race,
      ethnicity: this.addChildForm.value.ethniCity,
      gender: this.addChildForm.value.gender,
      dob: this.addChildForm.value.dob,
      document_disability: this.documentedDisabilityKey,
      permenent_residant: this.permanentResidentKey,

      childcarenedded: [
        {
          type: 'start_time',
          sunday: this.addChildForm.value.start_sunday,
          monday: this.addChildForm.value.start_monday,
          tuesday: this.addChildForm.value.start_tuesday,
          wednesday: this.addChildForm.value.start_wednesday,
          thursday: this.addChildForm.value.start_thursday,
          friday: this.addChildForm.value.start_friday,
          saturday: this.addChildForm.value.start_saturday,

          number_of_days: this.addChildForm.value.number_of_days,
          total_no_of_hours: this.addChildForm.value.total_no_of_hours,
          provider: this.addChildForm.value.provider,
        },
        {
          type: 'end_time',
          sunday: this.addChildForm.value.end_sunday,
          monday: this.addChildForm.value.end_monday,
          tuesday: this.addChildForm.value.end_tuesday,
          wednesday: this.addChildForm.value.end_wednesday,
          thursday: this.addChildForm.value.end_thursday,
          friday: this.addChildForm.value.end_friday,
          saturday: this.addChildForm.value.end_saturday,
        },
      ],
      identity_proof_of_child: [
        {
          type: this.addChildForm.value.proof_of_child,
          userkey: this.proof_of_childKey,
        },
        {
          type: this.addChildForm.value.relationship_to_child,
          userkey: this.relationship_to_child,
        },
      ],
    };
    console.log(this.addChildForm.value);
    // if(this.addChildForm){

    this.childservice.postChild(sendObj).subscribe({
      next: (res) => {
        console.log(res);
      },
      error: () => {
        alert('Error');
      },
    });
    // }
  }

  patch(masterKey: any) {
    let response: any;
    this.childservice.getChild(masterKey).subscribe({
      next: (res: any) => {
        console.log(res);
        response = res;
        console.log('res variablr', response);
        this.addChildForm.patchValue({
          lastname: response.lastname,
          firstname: response.firstname,
          mi: response.mi,
          ssn: response.ssn,
          race: response.race,
          ethnicity: response.ethnicity,
          dob: response.dob,
          gender: response.gender,
          number_of_days: response.childcarenedded[0].number_of_days,
          total_no_of_hours: response.childcarenedded[0].total_no_of_hours,
          provider: response.childcarenedded[0].name_of_provider,

          start_sunday: response.childcarenedded[0].sunday,
          start_monday: response.childcarenedded[0].monday,
          start_tuesday: response.childcarenedded[0].tuesday,
          start_wednesday: response.childcarenedded[0].wednesday,
          start_thursday: response.childcarenedded[0].thursday,
          start_friday: response.childcarenedded[0].friday,
          start_saturday: response.childcarenedded[0].saturday,

          end_sunday: response.childcarenedded[0].sunday,
          end_monday: response.childcarenedded[0].monday,
          end_tuesday: response.childcarenedded[0].tuesday,
          end_wednesday: response.childcarenedded[0].wednesday,
          end_thursday: response.childcarenedded[0].thursday,
          end_friday: response.childcarenedded[0].friday,
          end_saturday: response.childcarenedded[0].saturday,
        });
      },
      error: (err: any) => {
        alert('Error');
      },
    });
  }

  getAllChildren() {
    this.childservice.getChild().subscribe({
      next: (res) => {
        console.log(res);
      },
      error: (err) => {
        alert('Error');
      },
    });
  }
}
