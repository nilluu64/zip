import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class QuestioneriService {

  constructor(private http: HttpClient) { }

  postQuestioneri(data:any){
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
    return this.http.post<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/question/add',data,httpOptions)
  }

  getQuestioneri(masterKey?: any){
    return this.http.get('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/question/get/'+masterKey);
  }
}
