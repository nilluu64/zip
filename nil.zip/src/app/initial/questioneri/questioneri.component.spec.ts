import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestioneriComponent } from './questioneri.component';

describe('QuestioneriComponent', () => {
  let component: QuestioneriComponent;
  let fixture: ComponentFixture<QuestioneriComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuestioneriComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuestioneriComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
