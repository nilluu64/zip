import { TestBed } from '@angular/core/testing';

import { QuestioneriService } from './questioneri.service';

describe('QuestioneriService', () => {
  let service: QuestioneriService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QuestioneriService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
