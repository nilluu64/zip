import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { QuestioneriService } from './questioneri.service';

@Component({
  selector: 'app-questioneri',
  templateUrl: './questioneri.component.html',
  styleUrls: ['./questioneri.component.scss'],
})
export class QuestioneriComponent implements OnInit {
  questionForm: FormGroup;
  @Input() masterKey: any;
  @Input() key: any;
  masterKeys: any;
  agency = ['Agency101', 'Agency202', 'Agency303', 'Agency404'];

  constructor(
    private formBuilder: FormBuilder,
    private questioneri: QuestioneriService
  ) {}

  ngOnInit(): void {
    //  this.getQuestion();
    this.questionForm = this.formBuilder.group({
      food_stamp_program: [false],
      subsidy_under_tanf_program: [false],
      expirydate: [''],
      caseno: [''],
      case_dyfs_childrean: [false],
      dyfsoffice: [''],
      receiving_tanf_grant: [false],
      tanfcaseno: [''],
      medical_problems: [false],
      agency: [''],
      phoneno: [''],
      headhousehold: [false],
      homeless: [false],
      dyfsfoster_adaptive_home: [false],
      housing_assistance_directly: [false],
      ineligible_for_tcc: [false],
      active_duty_in_the_military: [false],
      national_guard_or_military_reserve: [false],
      full_time_active_duty_in_the_military: [false],
      snap_benefits: [false],
      snap_id: [''],
    });
  }

  patch(masterKey: any) {
    let response: any;
    this.questioneri.getQuestioneri(masterKey).subscribe({
      next: (res: any) => {
        console.log(res);
        response = res;
        console.log('res variablr', response);
        this.questionForm.patchValue({
          food_stamp_program: response.food_stamp_program,
          subsidy_under_tanf_program: response.subsidy_under_tanf_program,
          expirydate: response.expirydate,
          caseno: response.caseno,
          case_dyfs_childrean: response.case_dyfs_childrean,
          dyfsoffice: response.dyfsoffice,
          receiving_tanf_grant: response.receiving_tanf_grant,
          tanfcaseno: response.tanfcaseno,
          medical_problems: response.medical_problems,
          agency: response.agency,
          phoneno: response.phoneno,
          headhousehold: response.headhousehold,
          homeless: response.homeless,
          dyfsfoster_adaptive_home: response.dyfsfoster_adaptive_home,
          housing_assistance_directly: response.housing_assistance_directly,
          ineligible_for_tcc: response.ineligible_for_tcc,
          active_duty_in_the_military: response.active_duty_in_the_military,
          national_guard_or_military_reserve: response.national_guard_or_military_reserve,
          full_time_active_duty_in_the_military: response.full_time_active_duty_in_the_military,
          snap_benefits: response.snap_benefits,
          snap_id: response.snap_id,
        });
      },
    });
  }

  post() {
    let sendObj ={
      food_stamp_program: this.questionForm.value.food_stamp_program,
      subsidy_under_tanf_program: this.questionForm.value.subsidy_under_tanf_program,
  }
    console.log(this.questionForm.value);
    this.questioneri.postQuestioneri(sendObj).subscribe({
      next: (res) => {
        alert('Saved Succesfully');
      },
      error: () => {
        alert('Fill Demographic Form First...');
      },
    });
  }

  getQuestion() {
    this.questioneri.getQuestioneri().subscribe({
      next: (res) => {
        console.log(res);
      },
      error: () => {
        alert('Error');
      },
    });
  }
}
