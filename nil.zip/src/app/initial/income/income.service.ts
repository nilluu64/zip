import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class IncomeService {

  constructor(private http: HttpClient) { }

  postIncome(data:any){
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
    
    return this.http.post<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/income/add',data,httpOptions)
  }

  getIncome(masterKey?: any){
    console.log('from service',masterKey);
    return this.http.get('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/income/get/'+masterKey);
  }

}
