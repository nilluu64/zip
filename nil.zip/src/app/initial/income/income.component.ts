import { HttpClient } from '@angular/common/http';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { IncomeService } from './income.service';

@Component({
  selector: 'app-income',
  templateUrl: './income.component.html',
  styleUrls: ['./income.component.scss'],
})
export class IncomeComponent implements OnInit {
  
  appWagesSalarySelfProof: any;
  @Input() key: any;
  popKey:any;
  constructor(
    private formBuilder: FormBuilder,
    private incomeService: IncomeService,
    private http: HttpClient
  ) {}
  incomeForm: FormGroup;

  @Input() masterKey: any;

  frequency: ['Weekly', 'Bi-Weekly', 'Monthly'];
  race = ['Weekly', 'Bi-Weekly', 'Semi-Monthly', 'Monthly'];

  file: any;
  errData: any;
  masterKeys: any;

  appwasselfKey: any;
  appwasself: string = 'App  Wages and Salary Self';
  cowasselfKey: any;
  cowasself: string = 'Co-App  Wages and Salary Self';

  appwasallKey: any;
  appwasall: string = 'App  Wages and Salary All';
  coappwasallKey: any;
  coappwasall: string = 'Co-App  Wages and Salary All';

  apppensionKey: any;
  apppension: string = 'App Pension and Retirement';
  coapppensionKey: any;
  coapppension: string = 'Co-App Pension and Retirement';

  appsupplimentalKey: any;
  appsupplimental: string = 'App Suplimental and Benifits';
  coappsupplimentalKey: any;
  coappsupplimental: string = 'Co-AppSuplimental and Benifits';

  appunemploymentKey: any;
  appunemployment: string = 'App Unemployment';
  coappunemploymentKey: any;
  coappunemployment: string = 'Co-App Unemployment';

  appmilitaryKey: any;
  appmilitary: string = 'App Military';
  coappmilitaryKey: any;
  coappmilitary: string = 'Co-App Military';

  appdisabilityKey: any;
  appdisability: string = 'App Disability';
  coappdisabilityKey: any;
  coappdisability: string = 'Co-App Disability';

  apptanfKey: any;
  apptanf: string = 'App TANF';
  coapptanfKey: any;
  coapptanf: string = 'Co-App TANF';

  appchildsupportKey: any;
  appchildsupport: string = 'App Child Support';
  coappchildsupportKey: any;
  coappchildsupport: string = 'Co-App Child support';

  appalimonyKey: any;
  appalimony: string = 'App Alimony';
  coappalimonyKey: any;
  coappalimony: string = 'Co-App Alimony';

  appotherKey: any;
  appother: string = 'App Other';
  coappotherKey: any;
  coappother: string = 'Co-App Other';

  totalAnnual: number = 0;
  calcTotInCo: number = 0;
  calcTotInApp: number = 0;
  WagesSalarySelfApp: number = 0;
  WagesSalarySelfAllApp: number = 0;
  pensionApp: number = 0;
  supBenifitsApp: number = 0;
  unemploymentApp: number = 0;
  vetransApp: number = 0;
  disabilityApp: number = 0;
  tanfApp: number = 0;
  childSupportApp: number = 0;
  alimonyApp: number = 0;
  othersApp: number = 0;

  annualAppTotal: number = 0;

  WagesSalarySelfCoApp: number = 0;
  WagesSalarySelfAllCoApp: number = 0;
  pensionCoApp: number = 0;
  supBenifitsCoApp: number = 0;
  unemploymentCoApp: number = 0;
  vetransCoApp: number = 0;
  disabilityCoApp: number = 0;
  tanfCoApp: number = 0;
  childSupportCoApp: number = 0;
  alimonyCoApp: number = 0;
  othersCoApp: number = 0;
  annualCoAppTotal: number = 0;

  sumOfNumber: number = 0;
  sumOfNumber2: number = 0;

  ngOnInit(): void {
    this.incomeForm = this.formBuilder.group({
      anuual_Family_Income: [''],
      annualFamilyIncome: [],
      appWagesSalarySelfSelect:[''],
      appWagesSalaryAllfSelect: [],
      appPensionselect: [],
      appSupplementalselect: [],
      appCompansationSelect: [],
      appVeteransSelect: [],
      appDisabilitySelect: [],
      appTanfSelect: [],
      appChildSupportSelect: [],
      appAlimonySelect: [],
      appOtherSelect: [],

      coAppWagesSalarySelfSelect: [],
      coAppWagesSalaryAllSelect: [],
      coAppPensionSelect: [],
      coAppSupplementalSelect: [],
      coAppCompansationSelect: [],
      coAppVeteransSelect: [],
      coAppDisabilitySelect: [],
      coAppTanfSelect: [],
      coAppChildSupportSelect: [],
      coAppAlimonySelect: [],
      coAppOtherSelect: [],

      appWagesSalarySelf: [""],
      coAppWagesSalarySelf: [],
      appWagesSalaryAll: [],
      coAppWagesSalaryAll: [],
      appPension: [],
      coAppPension: [],
      appSupplemental: [],
      coAppSupplemental: [],
      appCompansation: [],
      coAppCompansation: [],
      appVeterans: [],
      coAppVeterans: [],
      appDisability: [],
      coAppDisability: [],
      appTanf: [],
      coAppTanf: [],
      appChildSupport: [],
      coAppChildSupport: [],
      appAlimony: [],
      coAppAlimony: [],
      appOther: [],
      coAppOther: [],
      appTotalGross: [],
      coAppTotalGross: [],

      appWagesSalarySelfProof: [],
      coAppWagesSalarySelfProof: [],
      appWagesSalaryAllproof: [],
      coAppWagesSalaryAllProof: [],
      appPensionProof: [],
      coAppPensionProof: [],
      appSupplementalProof: [],
      coAppSupplementalProof: [],
      appCompansationProof: [],
      coAppCompansationProof: [],
      appVeteransProof: [],
      coAppVeteransProof: [],
      appDisabilityProof: [],
      coAppDisabilityProof: [],
      appTanfProof: [],
      coAppTanfProof: [],
      appChildSupportProof: [],
      coAppChildSupportProof: [],
      appAlimonyProof: [],
      coAppAlimonyProof: [],
      appOtherProof: [],
      coAppOtherProof: [],
    });
  }

  dataKey(data:any){
    console.log(data);
    this.key = data
  }
 
  patch(masterKey: any) {
    let response: any;
    this.incomeService.getIncome(masterKey).subscribe({
      next: (res: any) => {
        console.log(res);
        response = res;
        console.log('res variablr', response);

        this.incomeForm.patchValue({
          annualFamilyIncome: response.annual_family_income,
          appWagesSalarySelf:
            response.applicant[0].grossincome.wagessalaryselfemployee,
          appWagesSalarySelfSelect:
            response.applicant[0].frequencyincome.wagessalaryselfemployee,
          appWagesSalaryAll:
            response.applicant[0].grossincome.wagessalaryallemployee,
          appWagesSalaryAllfSelect:
            response.applicant[0].frequencyincome.wagessalaryallemployee,
          appPension: response.applicant[0].grossincome.pensionsretirement,
          appPensionselect:
            response.applicant[0].frequencyincome.pensionsretirement,
          appSupplemental: response.applicant[0].grossincome.supplemental,
          appSupplementalselect:
            response.applicant[0].frequencyincome.supplemental,
          appCompansation: response.applicant[0].grossincome.unemployment,
          appCompansationSelect:
            response.applicant[0].frequencyincome.unemployment,
          appVeterans:
            response.applicant[0].grossincome.veterans_military_status,
          appVeteransSelect:
            response.applicant[0].frequencyincome.veterans_military_status,
          appDisability: response.applicant[0].grossincome.disability_benefits,
          appDisabilitySelect:
            response.applicant[0].frequencyincome.disability_benefits,
          appTanf: response.applicant[0].grossincome.tanfcashassistance,
          appTanfSelect:
            response.applicant[0].frequencyincome.tanfcashassistance,
          appChildSupport: response.applicant[0].grossincome.childsupport,
          appChildSupportSelect:
            response.applicant[0].frequencyincome.childsupport,
          appAlimony: response.applicant[0].grossincome.alimony,
          appAlimonySelect: response.applicant[0].frequencyincome.alimony,
          appOther: response.applicant[0].grossincome.others,
          appOtherSelect: response.applicant[0].frequencyincome.others,
          appTotalGross: response.applicant[0].grossincome.total_gross_income,

          coAppWagesSalarySelf:
            response.co_applicant[0].cgrossincome.wagessalaryselfemployee,
          coAppWagesSalarySelfSelect:
            response.co_applicant[0].cfrequencyincome.wagessalaryselfemployee,
          coAppWagesSalaryAll:
            response.co_applicant[0].cgrossincome.wagessalaryallemployee,
          coAppWagesSalaryAllfSelect:
            response.co_applicant[0].cfrequencyincome.wagessalaryallemployee,
          coAppPension:
            response.co_applicant[0].cgrossincome.pensionsretirement,
          coAppPensionselect:
            response.co_applicant[0].cfrequencyincome.pensionsretirement,
          coAppSupplemental: response.co_applicant[0].cgrossincome.supplemental,
          coAppSupplementalselect:
            response.co_applicant[0].cfrequencyincome.supplemental,
          coAppCompansation: response.co_applicant[0].cgrossincome.unemployment,
          coAppCompansationSelect:
            response.co_applicant[0].cfrequencyincome.unemployment,
          coAppVeterans:
            response.co_applicant[0].cgrossincome.veterans_military_status,
          coAppVeteransSelect:
            response.co_applicant[0].cfrequencyincome.veterans_military_status,
          coAppDisability:
            response.co_applicant[0].cgrossincome.disability_benefits,
          coAppDisabilitySelect:
            response.co_applicant[0].cfrequencyincome.disability_benefits,
          coAppTanf: response.co_applicant[0].cgrossincome.tanfcashassistance,
          coAppTanfSelect:
            response.co_applicant[0].cfrequencyincome.tanfcashassistance,
          coAppChildSupport: response.co_applicant[0].cgrossincome.childsupport,
          coAppChildSupportSelect:
            response.co_applicant[0].cfrequencyincome.childsupport,
          coAppAlimony: response.co_applicant[0].cgrossincome.alimony,
          coAppAlimonySelect: response.co_applicant[0].cfrequencyincome.alimony,
          coAppOther: response.co_applicant[0].cgrossincome.others,
          coAppOtherSelect: response.co_applicant[0].cfrequencyincome.others,
          coAppTotalGross:
            response.co_applicant[0].cgrossincome.total_gross_income,
        });
      },
      error: (err: any) => {
        alert('Error');
      },
    });
  }
  getFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
  }

  get anuual_Family_Income() {
    return this.incomeForm.get('annualFamilyIncome')!;
  }

  get appWagesSalarySelfProoff(){
    return this.incomeForm.get('appWagesSalarySelfProof')
  }
  get appWagesSalarySelff() {
    return this.incomeForm.get('appWagesSalarySelf')!;
  }
  get coAppWagesSalarySelff() {
    return this.incomeForm.get('coAppWagesSalarySelf')!;
  }
  get appWagesSalaryAll1() {
    return this.incomeForm.get('appWagesSalaryAll')!;
  }
  get coAppWagesSalaryAll1() {
    return this.incomeForm.get('coAppWagesSalaryAll')!;
  }
  get appPension1() {
    return this.incomeForm.get('appPension')!;
  }
  get coAppPension1() {
    return this.incomeForm.get('coAppPension')!;
  }
  get appSupplemental1() {
    return this.incomeForm.get('appSupplemental')!;
  }
  get coAppSupplemental1() {
    return this.incomeForm.get('coAppSupplemental')!;
  }
  get appCompansation1() {
    return this.incomeForm.get('appCompansation')!;
  }
  get coAppCompansation1() {
    return this.incomeForm.get('coAppCompansation')!;
  }
  get appVeterans1() {
    return this.incomeForm.get('appVeterans')!;
  }
  get coAppVeterans1() {
    return this.incomeForm.get('coAppVeterans')!;
  }
  get appDisability1() {
    return this.incomeForm.get('appDisability')!;
  }
  get coAppDisability1() {
    return this.incomeForm.get('coAppDisability')!;
  }
  get appTanf1() {
    return this.incomeForm.get('appTanf')!;
  }
  get coAppTanf1() {
    return this.incomeForm.get('coAppTanf')!;
  }
  get appChildSupport1() {
    return this.incomeForm.get('appChildSupport')!;
  }
  get coAppChildSupport1() {
    return this.incomeForm.get('coAppChildSupport')!;
  }
  get appAlimony1() {
    return this.incomeForm.get('appAlimony')!;
  }
  get coAppAlimony1() {
    return this.incomeForm.get('coAppAlimony')!;
  }
  get appOther1() {
    return this.incomeForm.get('appOther')!;
  }
  get coAppOther1() {
    return this.incomeForm.get('coAppOther')!;
  }
  
  numberOnly(event: { which: any; keyCode: any }): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
 

  appWagesSalarySelf(event: any) {
    let count;

    if (this.incomeForm.get('appWagesSalarySelfSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appWagesSalarySelf')?.value * 52;
    } else if (
      this.incomeForm.get('appWagesSalarySelfSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appWagesSalarySelf')?.value * 26;
    } else if (
      this.incomeForm.get('appWagesSalarySelfSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appWagesSalarySelf')?.value * 24;
    } else {
      count = this.incomeForm.get('appWagesSalarySelf')?.value * 12;
    }
    this.WagesSalarySelfApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant(); 

  }
  appWagesSalaryAll(event: any) {
    let count;
    if (this.incomeForm.get('appWagesSalaryAllfSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appWagesSalaryAll')?.value * 52;
    } else if (
      this.incomeForm.get('appWagesSalaryAllfSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appWagesSalaryAll')?.value * 26;
    } else if (
      this.incomeForm.get('appWagesSalaryAllfSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appWagesSalaryAll')?.value * 24;
    } else {
      count = this.incomeForm.get('appWagesSalaryAll')?.value * 12;
    }
    this.WagesSalarySelfAllApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appPension(event: any) {
    let count;

    if (this.incomeForm.get('appPensionselect')?.value === 'Weekly') {
      count = this.incomeForm.get('appPension')?.value * 52;
    } else if (this.incomeForm.get('appPensionselect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('appPension')?.value * 26;
    } else if (
      this.incomeForm.get('appPensionselect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appPension')?.value * 24;
    } else {
      count = this.incomeForm.get('appPension')?.value * 12;
    }
    this.pensionApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appSupplemental(event: any) {
    let count;

    if (this.incomeForm.get('appSupplementalselect')?.value === 'Weekly') {
      count = this.incomeForm.get('appSupplemental')?.value * 52;
    } else if (
      this.incomeForm.get('appSupplementalselect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appSupplemental')?.value * 26;
    } else if (
      this.incomeForm.get('appSupplementalselect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appSupplemental')?.value * 24;
    } else {
      count = this.incomeForm.get('appSupplemental')?.value * 12;
    }
    this.supBenifitsApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appCompansation(event: any) {
    let count;
    if (this.incomeForm.get('appCompansationSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appCompansation')?.value * 52;
    } else if (
      this.incomeForm.get('appCompansationSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appCompansation')?.value * 26;
    } else if (
      this.incomeForm.get('appCompansationSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appCompansation')?.value * 24;
    } else {
      count = this.incomeForm.get('appCompansation')?.value * 12;
    }
    this.unemploymentApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appVeterans(event: any) {
    let count;
    if (this.incomeForm.get('appVeteransSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appVeterans')?.value * 52;
    } else if (
      this.incomeForm.get('appVeteransSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appVeterans')?.value * 26;
    } else if (
      this.incomeForm.get('appVeteransSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appVeterans')?.value * 24;
    } else {
      count = this.incomeForm.get('appVeterans')?.value * 12;
    }
    this.vetransApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appDisability(event: any) {
    let count;
    if (this.incomeForm.get('appDisabilitySelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appDisability')?.value * 52;
    } else if (
      this.incomeForm.get('appDisabilitySelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appDisability')?.value * 26;
    } else if (
      this.incomeForm.get('appDisabilitySelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appDisability')?.value * 24;
    } else {
      count = this.incomeForm.get('appDisability')?.value * 12;
    }
    this.disabilityApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appTanf(event: any) {
    let count;
    if (this.incomeForm.get('appTanfSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appTanf')?.value * 52;
    } else if (this.incomeForm.get('appTanfSelect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('appTanf')?.value * 26;
    } else if (this.incomeForm.get('appTanfSelect')?.value === 'Semi-Monthly') {
      count = this.incomeForm.get('appTanf')?.value * 24;
    } else {
      count = this.incomeForm.get('appTanf')?.value * 12;
    }
    this.tanfApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appChildSupport(event: any) {
    let count;
    if (this.incomeForm.get('appChildSupportSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appChildSupport')?.value * 52;
    } else if (
      this.incomeForm.get('appChildSupportSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('appChildSupport')?.value * 26;
    } else if (
      this.incomeForm.get('appChildSupportSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appChildSupport')?.value * 24;
    } else {
      count = this.incomeForm.get('appChildSupport')?.value * 12;
    }
    this.childSupportApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appAlimony(event: any) {
    let count;
    if (this.incomeForm.get('appAlimonySelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appAlimony')?.value * 52;
    } else if (this.incomeForm.get('appAlimonySelect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('appAlimony')?.value * 26;
    } else if (
      this.incomeForm.get('appAlimonySelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appAlimony')?.value * 24;
    } else {
      count = this.incomeForm.get('appAlimony')?.value * 12;
    }
    this.alimonyApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }
  appOther(event: any) {
    let count;
    if (this.incomeForm.get('appOtherSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('appOther')?.value * 52;
    } else if (this.incomeForm.get('appOtherSelect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('appOther')?.value * 26;
    } else if (
      this.incomeForm.get('appOtherSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('appOther')?.value * 24;
    } else {
      count = this.incomeForm.get('appOther')?.value * 12;
    }
    this.othersApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeApplicant();
  }

  coAppWagesSalarySelf(event: any) {
    let count;
    if (this.incomeForm.get('coAppWagesSalarySelfSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppWagesSalarySelf')?.value * 52;
    } else if (
      this.incomeForm.get('coAppWagesSalarySelfSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppWagesSalarySelf')?.value * 26;
    } else if (
      this.incomeForm.get('coAppWagesSalarySelfSelect')?.value ===
      'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppWagesSalarySelf')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppWagesSalarySelf')?.value * 12;
    }
    this.WagesSalarySelfCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppWagesSalaryAll(event: any) {
    let count;
    if (this.incomeForm.get('coAppWagesSalaryAllSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppWagesSalaryAll')?.value * 52;
    } else if (
      this.incomeForm.get('coAppWagesSalaryAllSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppWagesSalaryAll')?.value * 26;
    } else if (
      this.incomeForm.get('coAppWagesSalaryAllSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppWagesSalaryAll')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppWagesSalaryAll')?.value * 12;
    }

    this.WagesSalarySelfAllCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppPension(event: any) {
    let count;
    if (this.incomeForm.get('coAppPensionSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppPension')?.value * 52;
    } else if (
      this.incomeForm.get('coAppPensionSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppPension')?.value * 26;
    } else if (
      this.incomeForm.get('coAppPensionSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppPension')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppPension')?.value * 12;
    }
    this.pensionCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppSupplemental(event: any) {
    let count;
    if (this.incomeForm.get('coAppSupplementalSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppSupplemental')?.value * 52;
    } else if (
      this.incomeForm.get('coAppSupplementalSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppSupplemental')?.value * 26;
    } else if (
      this.incomeForm.get('coAppSupplementalSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppSupplemental')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppSupplemental')?.value * 12;
    }
    this.supBenifitsCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppCompansation(event: any) {
    let count;
    if (this.incomeForm.get('coAppCompansationSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppCompansation')?.value * 52;
    } else if (
      this.incomeForm.get('coAppCompansationSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppCompansation')?.value * 26;
    } else if (
      this.incomeForm.get('coAppCompansationSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppCompansation')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppCompansation')?.value * 12;
    }
    this.unemploymentCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppVeterans(event: any) {
    let count;
    if (this.incomeForm.get('coAppVeteransSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppVeterans')?.value * 52;
    } else if (
      this.incomeForm.get('coAppVeteransSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppVeterans')?.value * 26;
    } else if (
      this.incomeForm.get('coAppVeteransSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppVeterans')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppVeterans')?.value * 12;
    }
    this.vetransCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppDisability(event: any) {
    let count;
    if (this.incomeForm.get('coAppDisabilitySelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppDisability')?.value * 52;
    } else if (
      this.incomeForm.get('coAppDisabilitySelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppDisability')?.value * 26;
    } else if (
      this.incomeForm.get('coAppDisabilitySelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppDisability')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppDisability')?.value * 12;
    }
    this.disabilityCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppTanf(event: any) {
    let count;
    if (this.incomeForm.get('coAppTanfSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppTanf')?.value * 52;
    } else if (this.incomeForm.get('coAppTanfSelect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('coAppTanf')?.value * 26;
    } else if (
      this.incomeForm.get('coAppTanfSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppTanf')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppTanf')?.value * 12;
    }
    this.tanfCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppChildSupport(event: any) {
    let count;
    if (this.incomeForm.get('coAppChildSupportSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppChildSupport')?.value * 52;
    } else if (
      this.incomeForm.get('coAppChildSupportSelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppChildSupport')?.value * 26;
    } else if (
      this.incomeForm.get('coAppChildSupportSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppChildSupport')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppChildSupport')?.value * 12;
    }
    this.childSupportCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppAlimony(event: any) {
    let count;
    if (this.incomeForm.get('coAppAlimonySelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppAlimony')?.value * 52;
    } else if (
      this.incomeForm.get('coAppAlimonySelect')?.value === 'Bi-Weekly'
    ) {
      count = this.incomeForm.get('coAppAlimony')?.value * 26;
    } else if (
      this.incomeForm.get('coAppAlimonySelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppAlimony')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppAlimony')?.value * 12;
    }
    this.alimonyCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }
  coAppOther(event: any) {
    let count;
    if (this.incomeForm.get('coAppOtherSelect')?.value === 'Weekly') {
      count = this.incomeForm.get('coAppOther')?.value * 52;
    } else if (this.incomeForm.get('coAppOtherSelect')?.value === 'Bi-Weekly') {
      count = this.incomeForm.get('coAppOther')?.value * 26;
    } else if (
      this.incomeForm.get('coAppOtherSelect')?.value === 'Semi-Monthly'
    ) {
      count = this.incomeForm.get('coAppOther')?.value * 24;
    } else {
      count = this.incomeForm.get('coAppOther')?.value * 12;
    }
    // if (this.incomeForm.get('coAppOtherSelect')?.value === 'Weekly') {
    //   count = this.incomeForm.get('coAppOther')?.value  * 4;
    // } else if (this.incomeForm.get('coAppOtherSelect')?.value === 'Bi-Weekly') {
    //   count = this.incomeForm.get('coAppOther')?.value  * 2;
    // } else {
    //   count = this.incomeForm.get('coAppOther')?.value  * 1;
    // }
    this.othersCoApp = count;
    this.annualFamilyIncome();
    this.calTotalIncomeCoApplicant();
  }

  calTotalIncomeApplicant() {
    this.calcTotInApp =
      this.WagesSalarySelfApp +
      this.WagesSalarySelfAllApp +
      this.pensionApp +
      this.supBenifitsApp +
      this.unemploymentApp +
      this.vetransApp +
      this.disabilityApp +
      this.tanfApp +
      this.childSupportApp +
      this.alimonyApp +
      this.othersApp;
    return this.incomeForm.get('appTotalGross')?.setValue(this.calcTotInApp);
  }

  calTotalIncomeCoApplicant() {
    this.calcTotInCo =
      this.WagesSalarySelfCoApp +
      this.WagesSalarySelfAllCoApp +
      this.pensionCoApp +
      this.supBenifitsCoApp +
      this.unemploymentCoApp +
      this.vetransCoApp +
      this.disabilityCoApp +
      this.tanfCoApp +
      this.childSupportCoApp +
      this.alimonyCoApp +
      this.othersCoApp;

    return this.incomeForm.get('coAppTotalGross')?.setValue(this.calcTotInCo);
  }
  annualFamilyIncome() {
    this.annualCoAppTotal =
      this.WagesSalarySelfCoApp +
      this.WagesSalarySelfAllCoApp +
      this.pensionCoApp +
      this.supBenifitsCoApp +
      this.unemploymentCoApp +
      this.vetransCoApp +
      this.disabilityCoApp +
      this.tanfCoApp +
      this.childSupportCoApp +
      this.alimonyCoApp +
      this.othersCoApp;

    this.annualAppTotal =
      this.WagesSalarySelfApp +
      this.WagesSalarySelfAllApp +
      this.pensionApp +
      this.supBenifitsApp +
      this.unemploymentApp +
      this.vetransApp +
      this.disabilityApp +
      this.tanfApp +
      this.childSupportApp +
      this.alimonyApp +
      this.othersApp;

    this.incomeForm
      .get('annualFamilyIncome')
      ?.setValue(this.annualCoAppTotal + this.annualAppTotal);
  }

  post() {
    
    let sendobj = {
      id: this.key,
      familyassetsmorethan: this.incomeForm.value.annual_family_income,
      annual_family_income: this.incomeForm.value.annualFamilyIncome,
      applicant: [
        {
          grossincome: {
            wagessalaryallemployee: this.incomeForm.value.appWagesSalaryAll,
            wagessalaryselfemployee: this.incomeForm.value.appWagesSalarySelf,
            pensionsretirement: this.incomeForm.value.appPension,
            supplemental: this.incomeForm.value.appSupplemental,
            unemployment: this.incomeForm.value.appCompansation,
            veterans_military_status: this.incomeForm.value.appVeterans,
            disability_benefits: this.incomeForm.value.appDisability,
            tanfcashassistance: this.incomeForm.value.appTanf,
            childsupport: this.incomeForm.value.appChildSupport,
            alimony: this.incomeForm.value.appAlimony,
            others: this.incomeForm.value.appOther,
            total_gross_income: this.incomeForm.value.appTotalGross,
            applicant_gross_income_proof: {
              wagessalaryallemployee: this.appwasselfKey,
              wagessalaryselfemployee: this.appwasallKey,
              pensionsretirement: this.apppensionKey,
              supplemental: this.appsupplimentalKey,
              unemployment: this.appunemploymentKey,
              veterans_military_status: this.appmilitaryKey,
              disability_benefits: this.appdisabilityKey,
              tanfcashassistance: this.apptanfKey,
              childsupport: this.appchildsupportKey,
              alimony: this.appalimonyKey,
              others: this.appotherKey,
            },
          },
          frequencyincome: {
            wagessalaryallemployee:
              this.incomeForm.value.appWagesSalaryAllfSelect,
            wagessalaryselfemployee:
              this.incomeForm.value.appWagesSalarySelfSelect,
            pensionsretirement: this.incomeForm.value.appPensionselect,
            supplemental: this.incomeForm.value.appSupplementalselect,
            unemployment: this.incomeForm.value.appCompansationSelect,
            veterans_military_status: this.incomeForm.value.appVeteransSelect,
            disability_benefits: this.incomeForm.value.appDisabilitySelect,
            tanfcashassistance: this.incomeForm.value.appTanfSelect,
            childsupport: this.incomeForm.value.appChildSupportSelect,
            alimony: this.incomeForm.value.appAlimonySelect,
            others: this.incomeForm.value.appOtherSelect,
            total_gross_income: this.incomeForm.value.appTotalGross,
          },
        },
      ],
      co_applicant: [
        {
          cgrossincome: {
            wagessalaryallemployee: this.incomeForm.value.coAppWagesSalaryAll,
            wagessalaryselfemployee: this.incomeForm.value.coAppWagesSalarySelf,
            pensionsretirement: this.incomeForm.value.coAppPension,
            supplemental: this.incomeForm.value.coAppSupplemental,
            unemployment: this.incomeForm.value.coAppCompansation,
            veterans_military_status: this.incomeForm.value.coAppVeterans,
            disability_benefits: this.incomeForm.value.coAppDisability,
            tanfcashassistance: this.incomeForm.value.coAppTanf,
            childsupport: this.incomeForm.value.coAppChildSupport,
            alimony: this.incomeForm.value.coAppAlimony,
            others: this.incomeForm.value.coAppOther,
            total_gross_income: this.incomeForm.value.coAppTotalGross,
            co_applicant_gross_income_proof: {
              wagessalaryallemployee: this.cowasselfKey,
              wagessalaryselfemployee: this.coappwasallKey,
              pensionsretirement: this.coapppensionKey,
              supplemental: this.coappsupplimentalKey,
              unemployment: this.coappunemploymentKey,
              veterans_military_status: this.appmilitaryKey,
              disability_benefits: this.coappdisabilityKey,
              tanfcashassistance: this.coapptanfKey,
              childsupport: this.coappchildsupportKey,
              alimony: this.coappalimonyKey,
              others: this.coappotherKey,
            },
          },
          cfrequencyincome: {
            wagessalaryallemployee:
              this.incomeForm.value.coAppWagesSalaryAllSelect,
            wagessalaryselfemployee:
              this.incomeForm.value.coAppWagesSalarySelfSelect,
            pensionsretirement: this.incomeForm.value.coAppPensionSelect,
            supplemental: this.incomeForm.value.coAppSupplementalSelect,
            unemployment: this.incomeForm.value.coAppCompansationSelect,
            veterans_military_status: this.incomeForm.value.coAppVeteransSelect,
            disability_benefits: this.incomeForm.value.coAppDisabilitySelect,
            tanfcashassistance: this.incomeForm.value.coAppTanfSelect,
            childsupport: this.incomeForm.value.coAppChildSupportSelect,
            alimony: this.incomeForm.value.coAppAlimonySelect,
            others: this.incomeForm.value.coAppOtherSelect,
            total_gross_income: this.incomeForm.value.appTotalGross,
          },
        },
      ],
    };
    this.incomeService.postIncome(sendobj).subscribe({
      next: (res) => {
        alert('Saved Succesfully');
      },
      error: () => {
        alert('Fill Demographic Form First...');
      },
    });
  

  }
  getIncomeData() {
    this.incomeService.getIncome().subscribe({
      next: (res) => {
        console.log(res);
      },
      error: (err) => {
        alert('Error');
      },
    });
  }

  appWasself(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appwasself) {
      var filedata = {
        description: this.appwasself,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appwasselfKey = newStr;
          },
        });
    }
  }
  coWasself(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.cowasself) {
      var filedata = {
        description: this.cowasself,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.cowasselfKey = newStr;
          },
        });
    }
  }

  appWasall(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appwasall) {
      var filedata = {
        description: this.appwasall,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appwasallKey = newStr;
          },
        });
    }
  }
  coappWasall(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappwasall) {
      var filedata = {
        description: this.coappwasall,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappwasallKey = newStr;
          },
        });
    }
  }
  appPensionFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.apppension) {
      var filedata = {
        description: this.apppension,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.apppensionKey = newStr;
          },
        });
    }
  }
  coAppPensionFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coapppension) {
      var filedata = {
        description: this.coapppension,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coapppensionKey = newStr;
          },
        });
    }
  }
  appSupplimental(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appsupplimental) {
      var filedata = {
        description: this.appsupplimental,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appsupplimentalKey = newStr;
          },
        });
    }
  }
  coAppSupplimental(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappsupplimental) {
      var filedata = {
        description: this.coappsupplimental,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappsupplimentalKey = newStr;
          },
        });
    }
  }
  appUnemployment(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appunemployment) {
      var filedata = {
        description: this.appunemployment,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appunemploymentKey = newStr;
          },
        });
    }
  }
  coAppunemployment(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappunemployment) {
      var filedata = {
        description: this.coappunemployment,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappunemploymentKey = newStr;
          },
        });
    }
  }
  appMilitary(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appmilitary) {
      var filedata = {
        description: this.appmilitary,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appmilitaryKey = newStr;
          },
        });
    }
  }
  coAppmilitary(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappmilitary) {
      var filedata = {
        description: this.coappmilitary,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappmilitaryKey = newStr;
          },
        });
    }
  }
  appDisabilityFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appdisability) {
      var filedata = {
        description: this.appdisability,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appdisabilityKey = newStr;
          },
        });
    }
  }
  coAppDisabilityFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappdisability) {
      var filedata = {
        description: this.coappdisability,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappdisabilityKey = newStr;
          },
        });
    }
  }
  appTanfFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.apptanf) {
      var filedata = {
        description: this.apptanf,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.apptanfKey = newStr;
          },
        });
    }
  }
  coAppTanfFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coapptanf) {
      var filedata = {
        description: this.coapptanf,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coapptanfKey = newStr;
          },
        });
    }
  }
  appChildSupportFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appchildsupport) {
      var filedata = {
        description: this.appchildsupport,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appchildsupportKey = newStr;
          },
        });
    }
  }
  coAppChildSupportFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappchildsupport) {
      var filedata = {
        description: this.coappchildsupport,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappchildsupportKey = newStr;
          },
        });
    }
  }
  appAlimonyFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appalimony) {
      var filedata = {
        description: this.appalimony,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appalimonyKey = newStr;
          },
        });
    }
  }
  coAppAlimonyFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappalimony) {
      var filedata = {
        description: this.coappalimony,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappalimonyKey = newStr;
          },
        });
    }
  }
  appOtherFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.appother) {
      var filedata = {
        description: this.appother,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.appotherKey = newStr;
          },
        });
    }
  }
  coAppOtherFile(event: any) {
    this.file = event.target.files[0];
    console.log('file', this.file);
    if (this.coappother) {
      var filedata = {
        description: this.coappother,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;

            var newStr = Str.replace('userkey:', '');

            console.log('newstr', newStr);
            this.coappotherKey = newStr;
          },
        });
    }
  }
}
