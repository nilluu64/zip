import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http:HttpClient) { }

  getUploadedFile(masterKey?: any){
    return this.http.get<any>("https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/get/1")
  }

  postUploadFile(data:any){
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'application/json'})
    }
    return this.http.post<any>('https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/add',data,httpOptions)
  }
}


