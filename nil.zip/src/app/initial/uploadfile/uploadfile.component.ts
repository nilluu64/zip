import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { UploadService } from './upload.service';

@Component({
  selector: 'app-uploadfile',
  templateUrl: './uploadfile.component.html',
  styleUrls: ['./uploadfile.component.scss'],
})
export class UploadfileComponent implements OnInit {
  @Input() key: any;
  @Input() masterKey: any;
  names:any;
  upload = [
    'Passport',
    'Utility Bills',
    'School Records',
    'Insurance Card',
    'Proof of Employment',
    'Proof of Income',
  ];
  file: any;
  name: any = [];
  files: any = [];
  dataFile: any = [];
  errData: any;
  nameKey: any;
  nameToChange: any=[];
  displayName:any;

  constructor(private http: HttpClient, private uploadService: UploadService) {}

  ngOnInit(): void {}


  getFile(event: any) {
    for (let i = 0; i < event.target.files.length; i++) {
      this.file = event.target.files[i];
      this.files.push(event.target.files[i]);
      // this.nameToChange.push(this.name);
      // console.log(this.nameToChange);
      console.log('file', this.files);
    }

    if (this.name) {
      var filedata = {
        description: this.name,
      };
      var formdata = new FormData();
      formdata.append('file', this.file);
      formdata.append(
        'filedata',
        new Blob([JSON.stringify(filedata)], { type: 'application/json' })
      );

      this.http
        .post(
          'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/addfile',
          formdata
        )
        .subscribe({
          next: (data) => {
            console.log('Sucessss===>', data);
          },
          error: (error) => {
            this.errData = error;
            console.log('errData', this.errData.error.text);
            var Str = this.errData.error.text;
            var newStr = Str.replace('userkey:', '');
            console.log('newstr', newStr);
            this.nameKey = newStr;
          },
        });
    }
  }

  // submitData() {
  //   var filedata = {
  //     description: this.name,
  //   };
  //   var formdata = new FormData();
  //   formdata.append('file', this.file);
  //   formdata.append(
  //     'filedata',
  //     new Blob([JSON.stringify(filedata)], { type: 'application/json' })
  //   );

  //   this.http
  //     .post(
  //       'https://qvulllj0r2.execute-api.us-east-1.amazonaws.com/dhs/upload/add',
  //       formdata
  //     )
  //     .subscribe({
  //       next: (res) => {
  //         this.getUpload();
  //         console.log(res);
  //       },
  //       error: () => {
  //         this.getUpload();
  //         console.error();

  //       },
  //     });
  // }
 
  postDataFile() {
    let sendObj = {
      id: this.key,
      description: this.name,
      userkey: this.nameKey,
    };
    this.uploadService.postUploadFile(sendObj).subscribe({
      next: (res) => {
        console.log(res);
      },
      error: () => {},
    });
  }
  getUpload() {
    this.uploadService.getUploadedFile().subscribe({
      next: (res) => {
        console.log(res);
        this.dataFile = res;
      },
      error: (err) => {
        alert('Error');
      },
    });
  }
}
