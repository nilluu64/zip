import { Component, OnInit, ViewChild } from '@angular/core';
import { AddchildComponent } from './addchild/addchild.component';
import { DemographicComponent } from './demographic/demographic.component';
import { EmploymentComponent } from './employment/employment.component';
import { IncomeComponent } from './income/income.component';
import { QuestioneriComponent } from './questioneri/questioneri.component';

@Component({
  selector: 'app-initial',
  templateUrl: './initial.component.html',
  styleUrls: ['./initial.component.scss']
})
export class InitialComponent implements OnInit {
  @ViewChild(DemographicComponent) private demographicComponent: DemographicComponent;
  @ViewChild(IncomeComponent) private incomeComponent: IncomeComponent;
  @ViewChild(AddchildComponent) private addchildcomponent: IncomeComponent;
  @ViewChild(EmploymentComponent) private employmentcomponent: EmploymentComponent;
  @ViewChild(QuestioneriComponent) private questioneriComponemt: QuestioneriComponent

  key:any;
  inputKey:any;
  constructor() { }

  ngOnInit(): void {
  }

  dataKey(data:any){
    console.log(data);
    this.key = data
  }

  onClickBtn(inputKe: any) {
    this.demographicComponent.patch(inputKe);
    this.incomeComponent.patch(inputKe);
    this.addchildcomponent.patch(inputKe);
    this.employmentcomponent.patch(inputKe);
    this.questioneriComponemt.patch(inputKe);
    console.log('dfdsf', inputKe);

  }

}
