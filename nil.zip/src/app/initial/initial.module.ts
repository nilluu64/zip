import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { InitialRoutingModule } from './initial-routing.module';
import { InitialComponent } from './initial.component';
import { MatTabsModule } from '@angular/material/tabs';
import { DemographicComponent } from './demographic/demographic.component';
import { IncomeComponent } from './income/income.component';
import { AddchildComponent } from './addchild/addchild.component';
import { EmploymentComponent } from './employment/employment.component';
import { QuestioneriComponent } from './questioneri/questioneri.component';
import { UploadfileComponent } from './uploadfile/uploadfile.component';
import { ReviewComponent } from './review/review.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatGridListModule } from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { MatTooltipModule } from '@angular/material/tooltip';
import { FormsModule } from '@angular/forms';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSelectModule} from '@angular/material/select';





@NgModule({
  declarations: [
    InitialComponent,
    DemographicComponent,
    IncomeComponent,
    EmploymentComponent,
    AddchildComponent,
    QuestioneriComponent,
    UploadfileComponent,
    ReviewComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    InitialRoutingModule,
    MatTabsModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    MatGridListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatTableModule,
    MatIconModule,
    MatButtonModule,
    HttpClientModule,
    MatTooltipModule,
    FormsModule,
    MatCheckboxModule,
    MatSelectModule
    
    
  ],
  providers: [CurrencyPipe]

})
export class InitialModule { }
